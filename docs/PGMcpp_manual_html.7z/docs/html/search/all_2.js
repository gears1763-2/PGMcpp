var searchData=
[
  ['bibliography_42',['Bibliography',['../citelist.html',1,'']]]
];
