var searchData=
[
  ['bibliography_30',['Bibliography',['../citelist.html',1,'']]]
];
