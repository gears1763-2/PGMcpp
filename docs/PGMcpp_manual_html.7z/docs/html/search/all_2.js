var searchData=
[
  ['bibliography_43',['Bibliography',['../citelist.html',1,'']]]
];
