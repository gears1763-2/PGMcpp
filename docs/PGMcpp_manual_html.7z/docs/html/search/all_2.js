var searchData=
[
  ['bibliography_45',['Bibliography',['../citelist.html',1,'']]]
];
