var searchData=
[
  ['getemissionskg_43',['getEmissionskg',['../classCombustion.html#af08a8c4c1266e4292c3fe1dca57722a4',1,'Combustion']]],
  ['getfuelconsumptionl_44',['getFuelConsumptionL',['../classCombustion.html#a0546635d95595e53d13c2d6b09e2df92',1,'Combustion']]]
];
