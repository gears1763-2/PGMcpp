var searchData=
[
  ['electricalload_82',['ElectricalLoad',['../classElectricalLoad.html',1,'']]]
];
