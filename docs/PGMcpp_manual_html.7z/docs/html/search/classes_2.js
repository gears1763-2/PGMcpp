var searchData=
[
  ['electricalload_84',['ElectricalLoad',['../classElectricalLoad.html',1,'']]]
];
