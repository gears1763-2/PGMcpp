var searchData=
[
  ['electricalload_97',['ElectricalLoad',['../classElectricalLoad.html',1,'']]]
];
