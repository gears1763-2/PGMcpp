var searchData=
[
  ['storagetype_598',['StorageType',['../Storage_8h.html#a6c29de45529a1faaf6cf960d318acb1a',1,'Storage.h']]]
];
