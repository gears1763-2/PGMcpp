var searchData=
[
  ['wave_323',['Wave',['../classWave.html#a2c278e9718ead6bb859c983eb4ee7379',1,'Wave::Wave(void)'],['../classWave.html#a0bbd2449a59908ba7a2c2a22ce2d41f6',1,'Wave::Wave(int, WaveInputs)']]],
  ['wind_324',['Wind',['../classWind.html#a1ab6a3745ef893797cfc04861358f9f0',1,'Wind::Wind(void)'],['../classWind.html#a272adfc50152ad059078c8d3cb294f38',1,'Wind::Wind(int, WindInputs)']]]
];
