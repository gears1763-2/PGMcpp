var searchData=
[
  ['bibliography_616',['Bibliography',['../citelist.html',1,'']]]
];
