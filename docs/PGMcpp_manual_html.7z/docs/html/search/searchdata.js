var indexSectionsWithContent =
{
  0: "cdefgilmnoprstw~",
  1: "cdelmprstw",
  2: "cdelmprstw",
  3: "cdeglmprstw~",
  4: "cdefilmnoprst",
  5: "c",
  6: "dn",
  7: "f"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "enums",
  6: "enumvalues",
  7: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Enumerations",
  6: "Enumerator",
  7: "Macros"
};

