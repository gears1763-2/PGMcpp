var searchData=
[
  ['hysteresis_5fsoc_514',['hysteresis_SOC',['../structLiIonInputs.html#ab78a91b5b790c9565a820a5e1a15b26e',1,'LiIonInputs::hysteresis_SOC()'],['../classLiIon.html#ae7bddf09cd3d7908bfddce765e9c96b0',1,'LiIon::hysteresis_SOC()']]]
];
