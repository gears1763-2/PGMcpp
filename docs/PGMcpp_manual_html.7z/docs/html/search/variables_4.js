var searchData=
[
  ['gas_5fconstant_5fjmolk_547',['gas_constant_JmolK',['../structLiIonInputs.html#a2b92eab40dac627cd514f6d9c5df259e',1,'LiIonInputs::gas_constant_JmolK()'],['../classLiIon.html#abe2b0d002faf2011850d875fc9a13f8b',1,'LiIon::gas_constant_JmolK()']]]
];
