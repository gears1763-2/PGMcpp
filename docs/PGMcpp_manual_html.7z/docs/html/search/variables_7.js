var searchData=
[
  ['n_5fpoints_291',['n_points',['../classProduction.html#ab3ff6014a953f14b706ddda4d96405b5',1,'Production']]],
  ['n_5fstarts_292',['n_starts',['../classProduction.html#abda2dbf619142ba190f22e0abb5e8000',1,'Production']]],
  ['net_5fpresent_5fcost_293',['net_present_cost',['../classProduction.html#a0d6aece66956df0e2e9e3d3a067ef335',1,'Production']]],
  ['nominal_5fdiscount_5fannual_294',['nominal_discount_annual',['../structProductionInputs.html#a342afd44eecdbf13cdf8ffb6594b607d',1,'ProductionInputs']]],
  ['nominal_5finflation_5fannual_295',['nominal_inflation_annual',['../structProductionInputs.html#a1647300af656e0b74d48d4fb50d57d4c',1,'ProductionInputs']]],
  ['nox_5femissions_5fintensity_5fkgl_296',['NOx_emissions_intensity_kgL',['../structDieselInputs.html#a5e3321278e8e7b40cad22c3347f4d136',1,'DieselInputs::NOx_emissions_intensity_kgL()'],['../classDiesel.html#a23eb6b234acbc05414aef30635154fb5',1,'Diesel::NOx_emissions_intensity_kgL()']]],
  ['nox_5femissions_5fvec_5fkg_297',['NOx_emissions_vec_kg',['../classCombustion.html#aa2c1cf055745b96d4fa2da24d29a3a93',1,'Combustion']]],
  ['nox_5fkg_298',['NOx_kg',['../structEmissions.html#ae70cd2ca665c6d3a9f69ea9d79161b60',1,'Emissions']]]
];
